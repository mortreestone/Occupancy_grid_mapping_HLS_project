// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2020.2 (64-bit)
// Copyright 1986-2020 Xilinx, Inc. All Rights Reserved.
// ==============================================================
#ifndef XOGM_H
#define XOGM_H

#ifdef __cplusplus
extern "C" {
#endif

/***************************** Include Files *********************************/
#ifndef __linux__
#include "xil_types.h"
#include "xil_assert.h"
#include "xstatus.h"
#include "xil_io.h"
#else
#include <stdint.h>
#include <assert.h>
#include <dirent.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>
#include <unistd.h>
#include <stddef.h>
#endif
#include "xogm_hw.h"

/**************************** Type Definitions ******************************/
#ifdef __linux__
typedef uint8_t u8;
typedef uint16_t u16;
typedef uint32_t u32;
typedef uint64_t u64;
#else
typedef struct {
    u16 DeviceId;
    u32 Control_BaseAddress;
} XOgm_Config;
#endif

typedef struct {
    u64 Control_BaseAddress;
    u32 IsReady;
} XOgm;

typedef u32 word_type;

/***************** Macros (Inline Functions) Definitions *********************/
#ifndef __linux__
#define XOgm_WriteReg(BaseAddress, RegOffset, Data) \
    Xil_Out32((BaseAddress) + (RegOffset), (u32)(Data))
#define XOgm_ReadReg(BaseAddress, RegOffset) \
    Xil_In32((BaseAddress) + (RegOffset))
#else
#define XOgm_WriteReg(BaseAddress, RegOffset, Data) \
    *(volatile u32*)((BaseAddress) + (RegOffset)) = (u32)(Data)
#define XOgm_ReadReg(BaseAddress, RegOffset) \
    *(volatile u32*)((BaseAddress) + (RegOffset))

#define Xil_AssertVoid(expr)    assert(expr)
#define Xil_AssertNonvoid(expr) assert(expr)

#define XST_SUCCESS             0
#define XST_DEVICE_NOT_FOUND    2
#define XST_OPEN_DEVICE_FAILED  3
#define XIL_COMPONENT_IS_READY  1
#endif

/************************** Function Prototypes *****************************/
#ifndef __linux__
int XOgm_Initialize(XOgm *InstancePtr, u16 DeviceId);
XOgm_Config* XOgm_LookupConfig(u16 DeviceId);
int XOgm_CfgInitialize(XOgm *InstancePtr, XOgm_Config *ConfigPtr);
#else
int XOgm_Initialize(XOgm *InstancePtr, const char* InstanceName);
int XOgm_Release(XOgm *InstancePtr);
#endif

void XOgm_Start(XOgm *InstancePtr);
u32 XOgm_IsDone(XOgm *InstancePtr);
u32 XOgm_IsIdle(XOgm *InstancePtr);
u32 XOgm_IsReady(XOgm *InstancePtr);
void XOgm_EnableAutoRestart(XOgm *InstancePtr);
void XOgm_DisableAutoRestart(XOgm *InstancePtr);

void XOgm_Set_xi(XOgm *InstancePtr, u32 Data);
u32 XOgm_Get_xi(XOgm *InstancePtr);
void XOgm_Set_yi(XOgm *InstancePtr, u32 Data);
u32 XOgm_Get_yi(XOgm *InstancePtr);
void XOgm_Set_thetai(XOgm *InstancePtr, u32 Data);
u32 XOgm_Get_thetai(XOgm *InstancePtr);
void XOgm_Set_angle(XOgm *InstancePtr, u32 Data);
u32 XOgm_Get_angle(XOgm *InstancePtr);
void XOgm_Set_z_t(XOgm *InstancePtr, u32 Data);
u32 XOgm_Get_z_t(XOgm *InstancePtr);
void XOgm_Set_grid(XOgm *InstancePtr, u64 Data);
u64 XOgm_Get_grid(XOgm *InstancePtr);

void XOgm_InterruptGlobalEnable(XOgm *InstancePtr);
void XOgm_InterruptGlobalDisable(XOgm *InstancePtr);
void XOgm_InterruptEnable(XOgm *InstancePtr, u32 Mask);
void XOgm_InterruptDisable(XOgm *InstancePtr, u32 Mask);
void XOgm_InterruptClear(XOgm *InstancePtr, u32 Mask);
u32 XOgm_InterruptGetEnabled(XOgm *InstancePtr);
u32 XOgm_InterruptGetStatus(XOgm *InstancePtr);

#ifdef __cplusplus
}
#endif

#endif
