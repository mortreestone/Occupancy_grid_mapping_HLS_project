// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2020.2 (64-bit)
// Copyright 1986-2020 Xilinx, Inc. All Rights Reserved.
// ==============================================================
#ifndef __linux__

#include "xstatus.h"
#include "xparameters.h"
#include "xogm.h"

extern XOgm_Config XOgm_ConfigTable[];

XOgm_Config *XOgm_LookupConfig(u16 DeviceId) {
	XOgm_Config *ConfigPtr = NULL;

	int Index;

	for (Index = 0; Index < XPAR_XOGM_NUM_INSTANCES; Index++) {
		if (XOgm_ConfigTable[Index].DeviceId == DeviceId) {
			ConfigPtr = &XOgm_ConfigTable[Index];
			break;
		}
	}

	return ConfigPtr;
}

int XOgm_Initialize(XOgm *InstancePtr, u16 DeviceId) {
	XOgm_Config *ConfigPtr;

	Xil_AssertNonvoid(InstancePtr != NULL);

	ConfigPtr = XOgm_LookupConfig(DeviceId);
	if (ConfigPtr == NULL) {
		InstancePtr->IsReady = 0;
		return (XST_DEVICE_NOT_FOUND);
	}

	return XOgm_CfgInitialize(InstancePtr, ConfigPtr);
}

#endif

