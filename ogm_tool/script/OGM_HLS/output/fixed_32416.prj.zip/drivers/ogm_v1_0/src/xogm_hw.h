// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2020.2 (64-bit)
// Copyright 1986-2020 Xilinx, Inc. All Rights Reserved.
// ==============================================================
// control
// 0x00 : Control signals
//        bit 0  - ap_start (Read/Write/COH)
//        bit 1  - ap_done (Read/COR)
//        bit 2  - ap_idle (Read)
//        bit 3  - ap_ready (Read)
//        bit 7  - auto_restart (Read/Write)
//        others - reserved
// 0x04 : Global Interrupt Enable Register
//        bit 0  - Global Interrupt Enable (Read/Write)
//        others - reserved
// 0x08 : IP Interrupt Enable Register (Read/Write)
//        bit 0  - enable ap_done interrupt (Read/Write)
//        bit 1  - enable ap_ready interrupt (Read/Write)
//        others - reserved
// 0x0c : IP Interrupt Status Register (Read/TOW)
//        bit 0  - ap_done (COR/TOW)
//        bit 1  - ap_ready (COR/TOW)
//        others - reserved
// 0x10 : Data signal of xi
//        bit 31~0 - xi[31:0] (Read/Write)
// 0x14 : reserved
// 0x18 : Data signal of yi
//        bit 31~0 - yi[31:0] (Read/Write)
// 0x1c : reserved
// 0x20 : Data signal of thetai
//        bit 31~0 - thetai[31:0] (Read/Write)
// 0x24 : reserved
// 0x28 : Data signal of angle
//        bit 31~0 - angle[31:0] (Read/Write)
// 0x2c : reserved
// 0x30 : Data signal of z_t
//        bit 31~0 - z_t[31:0] (Read/Write)
// 0x34 : reserved
// 0x38 : Data signal of grid
//        bit 31~0 - grid[31:0] (Read/Write)
// 0x3c : Data signal of grid
//        bit 31~0 - grid[63:32] (Read/Write)
// 0x40 : reserved
// (SC = Self Clear, COR = Clear on Read, TOW = Toggle on Write, COH = Clear on Handshake)

#define XOGM_CONTROL_ADDR_AP_CTRL     0x00
#define XOGM_CONTROL_ADDR_GIE         0x04
#define XOGM_CONTROL_ADDR_IER         0x08
#define XOGM_CONTROL_ADDR_ISR         0x0c
#define XOGM_CONTROL_ADDR_XI_DATA     0x10
#define XOGM_CONTROL_BITS_XI_DATA     32
#define XOGM_CONTROL_ADDR_YI_DATA     0x18
#define XOGM_CONTROL_BITS_YI_DATA     32
#define XOGM_CONTROL_ADDR_THETAI_DATA 0x20
#define XOGM_CONTROL_BITS_THETAI_DATA 32
#define XOGM_CONTROL_ADDR_ANGLE_DATA  0x28
#define XOGM_CONTROL_BITS_ANGLE_DATA  32
#define XOGM_CONTROL_ADDR_Z_T_DATA    0x30
#define XOGM_CONTROL_BITS_Z_T_DATA    32
#define XOGM_CONTROL_ADDR_GRID_DATA   0x38
#define XOGM_CONTROL_BITS_GRID_DATA   64

